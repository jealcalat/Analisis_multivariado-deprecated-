import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LogisticRegression, LinearRegression
from scipy.special import expit




xmin, xmax = -5, 5
n_samples = 100
np.random.seed(0)
X_trainer = np.random.normal(size=n_samples)
y_target = (X_trainer > 0).astype(float)
X_trainer[X_trainer > 0] *= 4
X_trainer += 0.3 * np.random.normal(size=n_samples)

X_trainer = X_trainer[:, np.newaxis]

plt.clf()
plt.scatter(X_trainer.ravel(), y_target, color="black", zorder=20)


# Parte 2
X_test = np.linspace(-5, 10, 300).reshape(300,1)



# Parte 3
RegLineal = LinearRegression()
RegLineal.fit(X_trainer, y_target)


plt.plot(X_test, RegLineal.coef_ * X_test + RegLineal.intercept_, linewidth=1)
plt.axhline(0.5, color=".5")



#Parte 4          !!!!!!!!!!!!!!!!!!!!!!!!!!!!

RegLog = LogisticRegression(C=1e5)
RegLog.fit(X_trainer, y_target)
loss = expit(X_test * RegLog.coef_ + RegLog.intercept_).ravel()
plt.plot(X_test, loss, color="red", linewidth=1)




plt.ylabel("y")
plt.xlabel("X")
plt.xticks(range(-5, 10))
plt.yticks([0, 0.5, 1])
plt.ylim(-0.25, 1.25)
plt.xlim(-4, 10)
plt.legend(
    ("Logistic Regression Model", "Linear Regression Model"),
    loc="lower right",
    fontsize="small",
)
plt.tight_layout()
plt.show()