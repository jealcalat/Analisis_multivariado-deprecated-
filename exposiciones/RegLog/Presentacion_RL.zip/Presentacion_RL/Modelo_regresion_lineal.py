# -*- coding: utf-8 -*-
"""
Created on Mon Oct 24 14:20:13 2022

@author: kglh299
"""
# Las librerias necesarias
from sklearn import datasets


# Aqui se mostrara el dataset a utilizar
dataset = datasets.load_breast_cancer()
print(dataset) #Aqui al imprimir el dataset podemos ver toda la informacion que contiene aunque no es totalmente entendible, sera necesario hecharnos un clavado al detalle, solo para entender,  
# Esto sera util para nosotros que no estamos tan familiarizados con la ciencia de datos.

# Imprimimos informacion del dataSet!
print(dataset.keys())

#Podemos Verificar las caracteristicas del DataSet
print(dataset.DESCR)
# Aqui seria bueno mostrar el el objeto DataSet y la informacion que nos da

# Cantidada de datos
# Cantidad de atributos . son 10
# Cada una de las variables tenemos la media, el error standar y el peor (Que vendia siendo la media de los 3 valos mas grandes. ) esto nos da los 30 atributos

# Datos a mencionar:
# el dataset no tiene datos perdidos por lo que el dataset esta completo, y no es necesario preprocesar para completar los datos perdidos.
# Tambien vemos la cantidad de benigno  y maligno, indica que los datos se encuentran balanceados y pues no nos tenemos que preocupar porque el dataset este desvalanceado.




#Vamos a definir nuestras variables para definir nuestro modelo 
X_dataset = dataset.data #
Y_target = dataset.target   #nos dice si el tumor fue benigno o maligno



#Vamos a definir los datos de prueba y de entrenamiento:
from sklearn.model_selection import train_test_split
X_trainer, X_test, Y_trainer, Y_test = train_test_split(X_dataset, Y_target, test_size=0.2)
# Aqui estamos separando nuestro set en dos, para el entrenamiento y para las pruebas, se tomara un 20% para las pruebas

#Se requiere escalar los datos
from sklearn.preprocessing import StandardScaler 
escalar = StandardScaler()
X_trainer = escalar.fit_transform(X_trainer)
X_test = escalar.transform(X_test)



# # #Traemos el modelo
from sklearn.linear_model import LogisticRegression
RegLog = LogisticRegression()
RegLog.fit(X_trainer, Y_trainer)



prediction = RegLog.predict(X_test)
# # Aqui vamos a ver una comparacion de los datos predichos contra los datos reales. podemos mostrar los valores de x_text y prediction.

# # Pero vamos a evaluar el rendimiento del modelo.

from sklearn.metrics import confusion_matrix
matriz = confusion_matrix(Y_test, prediction)
# Aqui podemos ver primer fila que el modelo datos verdaderos positivos y cuantos se acertaron incorrectamente. y segunda columna los falsos positivos.  donde el valor era 1 y el modelos lo predijo como 0.


from sklearn.metrics import precision_score
precision = precision_score(Y_test, prediction)
# Con la métrica de precisión podemos medir la calidad del modelo de machine learning en tareas de clasificación.
# Podemos ver la precision que hace match con lo vimos en la matriz de confusion.




from sklearn.metrics import recall_score
Exhaustividad = recall_score(Y_test, prediction) #o sensibilidad
# La métrica de exhaustividad nos va dar  es la fracción de instancias relevantes que han sido recuperadas






# # Ahora calculemos el valor F1 que hemos visto en clases pasadas.
from sklearn.metrics import f1_score
puntaje_F1 = f1_score(Y_test, prediction)
# El valor F1 se utiliza para combinar las medidas de precision y recall en un sólo valor.
# Esto es práctico porque hace más fácil el poder comparar el rendimiento combinado 
# de la precisión y la exhaustividad entre varias soluciones.


from sklearn.metrics import accuracy_score
exactitud = accuracy_score(Y_test, prediction)
# Peligro: la métrica accuracy (exactitud) no funciona bien cuando las 
# clases están desbalanceadas como es en este caso. La mayoría de los clientes 
# no están interesados en la oferta, así que es muy fácil acertar diciendo que no lo van a estar. 
# Para problemas con clases desbalanceadas es mucho mejor usar precision, recall y F1.
# Estas métricas dan una mejor idea de la calidad del modelo.


# from sklearn.metrics import roc_auc_score
# roc_auc = roc_auc_score(Y_test, prediction)





import statsmodels.api as sm
X2 = sm.add_constant(X_dataset)
est = sm.OLS(Y_target, X2)
est2 = est.fit()
print(est2.summary())

