import numpy as np
import pandas as pd
from pydataset import data
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

titanic = data('titanic')
titanic.sample(5)
titanic =pd.get_dummies(titanic, drop_first=True)

X_trainer, X_test, Y_trainer, Y_test = train_test_split(titanic.drop('survived_yes',axis=1),titanic['survived_yes'])

RegLog = LogisticRegression()
RegLog.fit(X_trainer, Y_trainer)



# Veamos, si sobreviviria una niña menor de edad de primera clase?
# |2da Clase   |3ra Clase |Niño|   Mujer|"
Sobrevieviente1 = np.array([[0,0,1,1]])
if RegLog.predict(Sobrevieviente1)[0]  == 1:
    print ("Vive")
else:
    print("Muere")

# Un hombre adulto tarcera clase
Sobrevieviente2 = np.array([[0,1,0,0]])
if RegLog.predict(Sobrevieviente2)[0]  == 1:
    print ("Vive")
else:
    print("Muere")

