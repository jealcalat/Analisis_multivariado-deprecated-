import pandas as pd

clientes = pd.read_csv("Test_escalar.csv", index_col = 0)

clientes.info()
clientes.describe()
indiv_sin_escalar = clientes.iloc[[0,6,7],]

import matplotlib.pyplot as plt
indiv_sin_escalar.plot(kind="bar")
plt.show()
# Vemos que es tan pequeño que no se ven el resto de las variables, por lo tanto no podemos comparar a los 3 individuos observando sus 3 caracteristicas.
# Entonces la estandarizacion y7o escalar los valores ayudara en estas comparativas o en algoritmos de machin learning que se ven afectados cuando algunas variables son muy grandes.


from sklearn.compose import ColumnTransformer 
from sklearn.preprocessing import MinMaxScaler

escalando = ColumnTransformer(
            [('escaladas', MinMaxScaler(feature_range=(0,1)), clientes.columns)])

clientes_escalados = escalando.fit_transform(clientes)
clientes_escalados = pd.DataFrame(clientes_escalados)
clientes_escalados.columns =list(clientes.columns.values)

indiv_escalados = clientes_escalados.iloc[[0,6,7],]
indiv_escalados.plot(kind="bar")
plt.legend(loc=(1.01,0.5))
plt.show()

# Todas nuestras variables tiene un valor entre 0 y 1 ,  










# y por ultimo lo vamos a estandarizar
# Buscamos que todas las variables tenga un valor promedio igual a cero y una desviacion estandar igual a 1
# para lograrlo a cada uno de los valores actuales se le resta el valor promedio de la variable a la que pertenece
# y el resultado obtenido se divide entre la desviacion estandar de la misma.

# Lo que estamos haciendo es obteniedo la distancia que cada uno de ellos tiene hacia la media pero en desviaciones estandar.

# Por ejemplo si el valor calculado es 1.7, quiere decir que el valor original esta a 1.7 desviaciones estandar de la media.
# y si el valor calculado es negativo, ejemplo -.52, significa que es menor que la media y se encuentra a .52 desviaciones estandar de la media.

from sklearn.preprocessing import StandardScaler
estandrizadas = ColumnTransformer(
            [('estandarizados', StandardScaler(), clientes.columns)])

clientes_estandarizados = estandrizadas.fit_transform(clientes)
clientes_estandarizados = pd.DataFrame(clientes_estandarizados)
clientes_estandarizados.columns =list(clientes.columns.values)
clientes_estandarizados.describe()

indiv_estandarizados = clientes_estandarizados.iloc[[0,6,7],]
indiv_estandarizados.plot(kind="bar")
plt.legend(loc=(1.01,0.5))
plt.show()


# Aqui la interpretacion seria la siguiente:
# Por ejemplo, vemos que el individuo 1 es mujer,  porque los valores originales son 0 y 1,    y aqui viene un valor estandarizado positivo en el grafico, lo mismo sucede en las variables maestria licenciatura y preparatoria, si los valores son positivos significa que originalmente es 1.
# Vemos otro comportamiento por ejemplo con la varible ingresos,  donde vemos que el individuo 6 tiene valor positivo y los otros no,  eso quiere decir que el individuo 6 gana mas que el promedio.

import seaborn as sns
sns.kdeplot(data=clientes).set(title='Clientes sin Estandarizar')
plt.show()
# Devido que como vimos los valores de ingreso es mucho mayor al de las otras variables, este grafico no nos proporciona nada de informacion.

sns.kdeplot(data=clientes_estandarizados).set(title='Clientes sin Estandarizar')
plt.show()
# en cambio si graficamos los valores estandarizados, podemos ver como estan distribuidos los datos de cada una de las variables.

# Fin de dato cultural
